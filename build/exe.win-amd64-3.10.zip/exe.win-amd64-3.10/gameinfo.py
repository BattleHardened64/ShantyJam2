#This file will store the game class
